from pathlib import Path
from fractions import Fraction as F
import json,re,math
root=Path(__file__).resolve().parent
j=json.loads((root/'certificate.json').read_text())
tokens=list(map(int,(root/'certificate.txt').read_text().split()))
rn,rd,B,D,R,ng,nt=tokens[:7]
assert len(tokens)==7+3*(ng+nt)
rows=[tokens[:7]]+[tokens[k:k+3] for k in range(7,len(tokens),3)]
assert F(rn,rd)==F(j['target'])==F(36869,20000)
assert B==j['bid_denominator']==10**8
assert D==j['mass_denominator']==10**9
assert R==j['radius_scale']==10**9
assert ng==len(j['gammas'])==13 and nt==len(j['times'])==121
assert len(rows)==1+ng+nt
G=1
for i,(an,ad,w) in enumerate(rows[1:1+ng]):
    assert F(an,ad)==F(j['gammas'][i])
    assert w==j['bid_integers'][i]
    G=math.lcm(G,ad)
assert G==4500
for i,(an,ad,c) in enumerate(rows[1+ng:]):
    assert F(an,ad)==F(j['times'][i])==1+F(i,96)
    assert c==j['mass_integers'][i]
assert sum(j['bid_integers'])==B and sum(j['mass_integers'])==D
tex=(root/'factor_revealing_184345.tex').read_text()
tab=tex[tex.index('\\label{tab:bid}'):tex.index('\\end{table}')]
found={int(i):(F(g),int(re.sub(r'[^0-9]','',w))) for i,g,w in re.findall(r'(\d+) & \$([^$]+)\$ & \$([0-9{},]+)\$',tab)}
assert found=={i+1:(F(g),w) for i,(g,w) in enumerate(zip(j['gammas'],j['bid_integers']))}
start=tex.index('\\label{tab:masses}')
tab=tex[start:tex.index('\\end{table}',start)]
found={int(i):int(re.sub(r'[^0-9]','',c)) for i,c in re.findall(r'(\d+) & \$([0-9{},]+)\$',tab)}
assert found==dict(enumerate(j['mass_integers']))
# Independent generation of all scalar endpoint sets (without path arithmetic).
g=list(map(F,j['gammas']));u=list(map(F,j['times']));rho=F(j['target'])
count=0;max_a=F(0);cdfslack=[]
for h in range(nt):
    upper=None if h<2 else u[h-1]/(u[h-1]-1)
    if upper is not None and upper<rho:continue
    pts={rho,*g,*u,*[t*(1+ga) for t in u for ga in g]}
    if upper is not None:pts.add(upper)
    if u[h]>1:pts.add(u[h]/(u[h]-1))
    for l in range(h):
        for ga in g:pts.update([1+ga/u[l],ga*u[h]/u[l]])
    pts={a for a in pts if rho<=a and (upper is None or a<=upper)}
    count+=len(pts);max_a=max(max_a,max(pts))
assert count==112802
beta=lambda x,y:sum((F(w,B)*max(F(0),x-ga*y) for ga,w in zip(g,j['bid_integers'])),F(0))
for l in range(1,nt):
    slack=F(sum(j['mass_integers'][:l]),D)-beta(u[l],F(1))/(u[l]-1)
    assert slack>=0;cdfslack.append(slack)
print('PASS: certificate.txt and certificate.json agree exactly.')
print('PASS: all 13 bid parameters and all 121 masses in the TeX match the certificate.')
print('PASS: independent endpoint enumeration:',count)
print('Largest finite endpoint:',max_a)
print('PASS: all 120 cumulative-mass inequalities hold exactly.')
print('Smallest CDF slack:',min(cdfslack))
