/* Exact verifier for the all-dimensions mixture certificate.
 * Compile: g++ -O3 -std=c++17 verify.cpp -o verify
 * Run:     ./verify certificate.txt
 * No floating-point arithmetic or optimization library is used.
 * See PROOF.md for the analytic reduction and for the input format.
 */
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <numeric>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
#include <boost/multiprecision/cpp_int.hpp>
using L=std::int64_t; using I=__int128_t; using Z=boost::multiprecision::cpp_int;
I absi(I a){return a<0?-a:a;}
I gcdi(I a,I b){a=absi(a);b=absi(b);while(b){I t=a%b;a=b;b=t;}return a;}
L small(I a){if(a<std::numeric_limits<L>::min()||a>std::numeric_limits<L>::max())throw std::overflow_error("rational component does not fit int64");return L(a);}
std::string stri(I a){if(a==0)return "0";bool neg=a<0;if(neg)a=-a;std::string s;while(a){s.push_back(char('0'+a%10));a/=10;}if(neg)s.push_back('-');std::reverse(s.begin(),s.end());return s;}
Z big(I a){return Z(stri(a));}
Z gcdz(Z a,Z b){if(a<0)a=-a;if(b<0)b=-b;while(b!=0){Z t=a%b;a=b;b=t;}return a;}
std::string fraction(Z a,Z b){Z g=gcdz(a,b);return (a/g).convert_to<std::string>()+"/"+(b/g).convert_to<std::string>();}
struct Q {
 L n,d;
 Q(I a=0,I b=1){if(b==0)throw std::runtime_error("zero denominator");if(b<0){a=-a;b=-b;}I g=gcdi(a,b);n=small(a/g);d=small(b/g);}
 bool operator<(Q b)const{return I(n)*b.d<I(b.n)*d;}
 bool operator==(Q b)const{return n==b.n&&d==b.d;}
 bool operator!=(Q b)const{return !(*this==b);}
 bool operator<=(Q b)const{return !(b<*this);}
 Q operator+(Q b)const{return Q(I(n)*b.d+I(b.n)*d,I(d)*b.d);}
 Q operator-(Q b)const{return Q(I(n)*b.d-I(b.n)*d,I(d)*b.d);}
 Q operator*(Q b)const{return Q(I(n)*b.n,I(d)*b.d);}
 Q operator/(Q b)const{return Q(I(n)*b.d,I(d)*b.n);}
 std::string text()const{return std::to_string(n)+(d==1?"":"/"+std::to_string(d));}
};
L flo(Q a,L scale){if(a.n<0)throw std::runtime_error("negative radius");return small(I(a.n)*scale/a.d);}
L cei(Q a,L scale){if(a.n<0)throw std::runtime_error("negative radius");return small((I(a.n)*scale+a.d-1)/a.d);}
struct Certificate {
 Q rho;L B,D,R,G=1;std::vector<Q> gamma,u;std::vector<L> W,M,p,sw,sp,pref;
 void read(const char*filename){
  std::ifstream in(filename);L rn,rd;int ng,nt;
  if(!(in>>rn>>rd>>B>>D>>R>>ng>>nt))throw std::runtime_error("invalid certificate header");
  rho=Q(rn,rd);if(B<=0||D<=0||R<=0||ng<1||nt<2||ng>1000||nt>1000||!(Q(1)<rho)||!(rho<Q(3)))throw std::runtime_error("invalid certificate constants");
  for(int k=0;k<ng;k++){L a,b,w;if(!(in>>a>>b>>w)||b<=0||w<0)throw std::runtime_error("invalid mixture entry");gamma.emplace_back(a,b);W.push_back(w);G=small(I(G/std::gcd(G,b))*b);}
  for(int l=0;l<nt;l++){L a,b,m;if(!(in>>a>>b>>m)||b<=0||m<0)throw std::runtime_error("invalid sampling entry");u.emplace_back(a,b);M.push_back(m);}
  if(u[0]!=Q(1))throw std::runtime_error("first threshold must equal one");
  if(!(u.back()/(u.back()-Q(1))<rho))throw std::runtime_error("the all-active case is not excluded");
  sw={0};sp={0};pref={0};
  for(int k=0;k<ng;k++){
   if(gamma[k]<Q(1)||(k&&!(gamma[k-1]<gamma[k])))throw std::runtime_error("gamma values must be sorted and at least one");
   p.push_back(small(I(gamma[k].n)*(G/gamma[k].d)));
   sw.push_back(small(I(sw.back())+W[k]));sp.push_back(small(I(sp.back())+I(W[k])*p.back()));
  }
  for(int l=0;l<nt;l++){
   if(l&&!(u[l-1]<u[l]))throw std::runtime_error("thresholds must be strictly increasing");
   pref.push_back(small(I(pref.back())+M[l]));
  }
  if(sw.back()!=B||pref.back()!=D)throw std::runtime_error("weights do not sum to one");
 }
 void cdf()const {
  for(int l=1;l<int(u.size());l++){
   Z numerator=0;
   for(int k=0;k<int(W.size());k++){
    Z term=Z(G)*u[l].n-Z(p[k])*u[l].d;
    if(term>0)numerator+=Z(W[k])*term;
   }
   if(Z(pref[l])*B*G*(u[l].n-u[l].d)<Z(D)*numerator)throw std::runtime_error("a CDF inequality fails");
  }
 }
 I beta(L x,L y)const {
  int lo=0,hi=p.size();
  while(lo<hi){int mid=(lo+hi)/2;if(I(G)*x>I(p[mid])*y)lo=mid+1;else hi=mid;}
  return I(G)*x*sw[lo]-I(y)*sp[lo];
 }
 std::vector<Q> endpoints(int h)const {
  bool finite=h>=2;Q upper=finite?u[h-1]/(u[h-1]-Q(1)):Q(0);
  if(finite&&upper<rho)return {};
  std::set<Q> out;
  auto add=[&](Q a){if(rho<=a&&(!finite||a<=upper))out.insert(a);};
  add(rho);if(finite)add(upper);if(Q(1)<u[h])add(u[h]/(u[h]-Q(1)));
  for(Q g:gamma)add(g); // Includes the points where the initial radius crosses a reference breakpoint.
  for(Q t:u){add(t);for(Q g:gamma)add(t*(Q(1)+g));}
  for(int l=0;l<h;l++)for(Q g:gamma){add(Q(1)+g/u[l]);add(g*u[h]/u[l]);}
  return {out.begin(),out.end()};
 }
 I check_case(int h,Q a,std::vector<Q>*path=nullptr)const {
  std::vector<Q> thresholds;std::set<Q> nodes={Q(0),a};
  for(Q g:gamma)if(g<=a)nodes.insert(g);
  for(Q t:u){Q b=a/t-Q(1);thresholds.push_back(b);if(Q(0)<=b&&b<=a)nodes.insert(b);}
  std::vector<Q> r(nodes.begin(),nodes.end());int nr=r.size(),nt=u.size();
  Q m=std::max(a-Q(1),a/u[h]);
  L xcap=small(I(cei((a+Q(1))*(u.back()+Q(1)),R))+1);
  // Independent arbitrary-precision bound on every intermediate of the
  // signed-128-bit recurrence. Fail rather than overflow on other inputs.
  Z cap=Z(16)*D*B*(Z(G)+sp.back()/B+1)*(nr+nt+10)*xcap;
  if(cap>=(Z(1)<<125))throw std::overflow_error("certificate exceeds the exact integer implementation's range");
  std::vector<L> lower(nr),upper(nr),spent(nr);
  std::vector<I> ref(nr),dp(nr);std::vector<int> predecessor(nr,0);
  for(int k=0;k<nr;k++){
   lower[k]=flo(r[k],R);upper[k]=cei(r[k],R);ref[k]=beta(lower[k],R);
   // thresholds are decreasing. Their strict comparison is made on the
   // exact rational radii, never on the rounded grid.
   int lo=0,hi=nt;
   while(lo<hi){int mid=(lo+hi)/2;if(r[k]<thresholds[mid])lo=mid+1;else hi=mid;}
   spent[k]=pref[std::max(h,lo)]-pref[h];
  }
  dp[0]=0;
  for(int k=1;k<nr;k++){
   bool first=true;I best=0;int arg=0;
   for(int j=0;j<k;j++){
    L mass=spent[j]-spent[k];if(mass<0)throw std::runtime_error("negative threshold mass");
    I val=I(D)*beta(upper[k],lower[j])-I(mass)*ref[k]+dp[j];
    if(first||best<val){best=val;arg=j;first=false;}
   }
   dp[k]=best;predecessor[k]=arg;
  }
  I active=0;
  for(int l=0;l<h;l++)active+=I(M[l])*beta(flo(m*u[l],R),R);
  I result=dp.back()-active;
  if(path){path->clear();int k=nr-1;path->push_back(r[k]);while(k>0){k=predecessor[k];path->push_back(r[k]);}}
  return result;
 }
};
int main(int argc,char**argv){
 try{
  if(argc<2){std::cerr<<"Usage: verify certificate.txt [h a_num a_den]\n";return 2;}
  Certificate c;c.read(argv[1]);c.cdf();Z denominator=Z(c.B)*c.G*c.R*c.D;
  if(argc==5){int h=std::stoi(argv[2]);Q a(std::stoll(argv[3]),std::stoll(argv[4]));std::vector<Q> path;I v=c.check_case(h,a,&path);std::cout<<fraction(big(v),denominator)<<"\n";for(Q x:path)std::cout<<x.text()<<" ";std::cout<<"\n";return 0;}
  bool first=true;I largest=0;int worsth=0;Q worsta;std::size_t count=0;
  for(int h=0;h<int(c.u.size());h++){
   auto points=c.endpoints(h);
   for(Q a:points){
    I v=c.check_case(h,a);count++;
    if(big(v)*c.rho.d>Z(c.rho.n)*denominator){std::cerr<<"FAIL h="<<h<<" a="<<a.text()<<" upper="<<fraction(big(v),denominator)<<"\n";return 1;}
    if(first||largest<v){first=false;largest=v;worsth=h;worsta=a;}
   }
  }
  if(first)throw std::runtime_error("empty collection of cases");
  std::vector<Q> path;c.check_case(worsth,worsta,&path);
  std::cout<<"PASS: exact all-dimensions threshold certificate\n"
   <<"Target: "<<c.rho.text()<<"\nMixture components: "<<c.gamma.size()<<"\nSampling thresholds: "<<c.u.size()
   <<"\nExact CDF inequalities: "<<c.u.size()-1<<"\nEndpoint cases: "<<count
   <<"\nLargest outward-rounded upper bound: "<<fraction(big(largest),denominator)
   <<"\nMargin: "<<fraction(Z(c.rho.n)*denominator-big(largest)*c.rho.d,denominator*c.rho.d)
   <<"\nWorst checked case: h="<<worsth<<", a="<<worsta.text()<<"\nWorst checked path:";
  for(Q x:path)std::cout<<" "<<x.text();std::cout<<"\n";
 }catch(const std::exception&e){std::cerr<<"ERROR: "<<e.what()<<"\n";return 2;}
}
