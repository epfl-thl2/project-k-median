from fractions import Fraction as F
G=list(map(F,['137/125','29/20','3/2','29/18','33/20','17/10','7/4','9/5','37/20','19/10','39/20','2','41/20']))
W=[66678856,616823,12834612,4845692,1922894,70695,1607203,659515,2091320,2245119,2936362,766770,2724139]
assert sum(W)==10**8

def beta(x,y):
    x,y=F(x),F(y)
    return sum((F(w,10**8)*max(F(0),x-g*y) for g,w in zip(G,W)),F(0))

z=F(17,10);M=1000;T=z+1;a=T-z/M
limit=z+beta(T,z)-beta(z,1)
finite=z+beta(a,z)-beta(z,1)
f=M*T+beta(z,1)
assert a>=z and beta(a,1)+M*a<=f
assert limit==F(8295524183431,4500000000000)
assert finite==F(16578788432339,9000000000000)
print('Exact asymptotic lower bound:',limit, '=',float(limit))
print('Exact 1001-client objective:',finite,'=',float(finite))
# The only nontrivial metric comparison is T-z=1; all cross-block
# triangle constraints hold with equality and both facility states
# have just been checked. The first row is a,z,...,z,0; all remaining
# rows are T,...,T,0. Distances are 1,0,...,0.
assert T-z==1
points=set([F(0)]+G+[1/(g-1) for g in G])
val,point=max((x+beta(x+1,x)-beta(x,1),x) for x in points)
mean=sum((F(w,10**8)*g for w,g in zip(W,G)),F(0))
print('Largest single-outlier diagnostic:',max(val,mean),'at',point if val>=mean else 'infinity')
print('PASS: exact lower-bound checks')
