# A threshold certificate for a convex mixture of bids

This note specifies the mathematical meaning of the certificate checked by `verify.cpp`. All parameters in `certificate.json` and `certificate.txt` are rational. A successful run proves an upper bound for the entire factor-revealing program, for every dimension; it is not a small-instance optimization or an extrapolation.

## 1. The optimization problem

Fix an integer n >= 1 and a bidding function beta on nonnegative pairs. Variables are f >= 0, d_j >= 0 (1 <= j <= n), and r_{j,i} >= 0 (1 <= j <= n and j <= i <= n+1). The objective is

    sum_j [sum_{i=j}^n beta(r_{j,i},r_{j,i+1}) + r_{j,n+1}] - f.

The constraints are

    sum_j d_j = 1;
    r_{j,i+1} <= r_{j,i}                         (j <= i <= n);
    r_{i,i} <= r_{j,i} + d_i + d_j               (j < i <= n);
    r_{j,l} <= r_{k,l} + d_j + d_k               (j,k < l <= n+1, j != k);
    sum_{j<i} beta(r_{j,i},d_j)
        + sum_{j>=i} beta(r_{i,i},d_j) <= f      (1 <= i <= n).

Write FR_n(beta) for its supremum. The certificate proves FR_n(beta) <= rho for all n. Equivalently, without the normalization, it proves that the total row charge is at most f + rho*sum_j d_j. There is no assumption that the diagonal entries are ordered.

## 2. Certificate parameters

The bid is a finite mixture

    beta(x,y) = sum_g w_g [x - gamma_g y]^+,
    w_g >= 0, sum_g w_g = 1, gamma_g >= 1.

Choose thresholds 1 = u_0 < ... < u_{L-1}, and masses mu_l >= 0 summing to one. Require

    rho > u_{L-1}/(u_{L-1}-1)

and, for l=1,...,L-1,

    sum_{k<l} mu_k >= beta(u_l,1)/(u_l-1).                    (CDF)

The mixture is homogeneous, jointly convex, nondecreasing in its first argument, and nonincreasing in its second argument. It satisfies beta(x,0)=x and 0 <= beta(x,y) <= [x-y]^+. It also satisfies beta(x,y)+beta(y,z) <= beta(x,z) for x >= y >= z: each hinge has this property, and taking a nonnegative mixture preserves it.

For h=0,...,L-1 define

    U_h = infinity                         if h=0 or 1,
          u_{h-1}/(u_{h-1}-1)              if h>=2;
    M_h(a) = max(a-1, a/u_h);
    A_h(a) = sum_{l<h} mu_l beta(M_h(a)u_l,1).

Only a in [rho,U_h] is needed; an empty interval contributes no cases. Put

    b_l(a) = a/u_l - 1;
    S_h(r;a) = sum_{l>=h, b_l(a)>r} mu_l.

The strict comparison is intentional.

For fixed h,a, form the distinct sorted radius states

    {0,a,gamma_g,a/u_l-1} intersected with [0,a],

and write them as 0=v_0 < ... < v_K=a. The scalar dynamic program is

    V_0=0;
    V_k=max_{p<k} {
        beta(v_k,v_p)
        -[S_h(v_p;a)-S_h(v_k;a)] beta(v_k,1)
        +V_p
    }.

The finite checks require V_K-A_h(a) <= rho at every endpoint specified in Section 6.

## 3. Sampling valid facility inequalities

Replacing every terminal radius by zero preserves feasibility and cannot decrease the objective, because beta(x,s)+s <= x=beta(x,0). Thus set all terminal radii to zero, write a_j=r_{j,j}, and let q_j be the sum of transition bids in row j. Telescoping gives q_j <= a_j.

For i>=2 define m_i=min_{j<i}(r_{j,i}+d_j). Choose m_1 positive and sufficiently large; set m_{n+1}=0. The triangle and metric constraints give

    r_{j,i} <= m_i+d_j          (j<=i),
    m_i <= r_{j,i}+d_j          (j<i).

The sequence m_i is nonincreasing. Indeed, an index attaining the minimum at i remains available at i+1, and its row can only decrease.

Let T_i=max_{p<=i} a_p, with T_0=0. The strengthened facility inequality

    sum_{j<i} beta(r_{j,i},d_j) + sum_{j>=i} beta(T_i,d_j) <= f

is valid. To prove it, choose h<=i with a_h=T_i and compare term by term with the original facility constraint at h. Rows with j<h have decreased since h. Rows with h<=j<i satisfy r_{j,i}<=a_j<=T_i. The remaining active arguments are a_h=T_i.

Use a virtual process: before event i, grow a clock from T_{i-1} to T_i, holding the center m_i and the inactive radii fixed. At event i, client i becomes inactive, the rows update, and the center decreases to m_{i+1}. Every clock-growth or pre-event state satisfies the facility inequality; each event only decreases reference bids.

For each threshold u_l, sample at the first crossing of clock/center >= u_l. If the crossing is caused by a center drop, sample immediately BEFORE the drop. Regard the ratio as infinity when the center is zero. This convention also defines a sample for a final zero-clock/zero-center state. Initially the ratio is zero, and eventually every threshold is sampled.

Let x_j(u_l) be the reference-bid argument of client j at that state: its clock value while active, or its row radius while inactive. Define

    C_j=sum_l mu_l beta(x_j(u_l),d_j).

Averaging valid facility inequalities yields sum_j C_j<=f. It therefore suffices to prove q_j<=rho*d_j+C_j for every row.

## 4. Zero distances and positive distances

Define kappa(u)=beta(u,1)/(u-1) for u>1, and let H(u)=sum_{u_l<u}mu_l. For a hinge mixture, kappa is nondecreasing, since each summand is [1-(gamma_g-1)/(u-1)]^+. Condition (CDF) implies H(u)>=kappa(u) at every u>1, including points between and beyond the sampled thresholds.

For a zero-distance row with positive initial radius, scale that radius to one. Write its decreasing path as 1=z_0>=...>=z_p=0. A sample at U is taken no later than the first row drop strictly below 1/U. This follows because, once the row is inactive, the clock is at least its initial value and the center is at most the row radius. If the crossing occurs on the activating event, the pre-event clock also has the required lower bound.

Consequently, the reference credit is at least

    sum_t (z_t-z_{t+1}) H(1/z_{t+1}),

with H(infinity)=1. For 0<y<x<=1,

    beta(x,y)/(x-y)=kappa(x/y)<=kappa(1/y)<=H(1/y).

The terminal case y=0 follows from beta(x,0)=x. Thus q_j<=C_j whenever d_j=0. A row with initial radius zero is trivial.

For d_j>0 scale the row by d_j, and write a=a_j/d_j and M=m_j/d_j. If a<=rho, telescoping already proves the required inequality. Otherwise M>=a-1>0. Let h be the number of thresholds with u_l<=a/M. The case h=L would imply a<=u_{L-1}/(u_{L-1}-1)<rho, so it cannot occur. For h>=2, the inequality M>=a-1 gives a<=U_h.

The first h samples are taken while the row is active. Each has normalized clock at least M*u_l, including a sample taken immediately before a center drop: that pre-drop center is at least M, and the threshold had not yet been crossed. Also M>=M_h(a). These samples therefore supply at least A_h(a).

For a remaining threshold, when a row drops from x to y<b_l(a), the post-event center is at most y+1<a/u_l and the virtual clock is at least a. Thus this threshold has already been sampled. If the sample was taken while inactive, its radius was at least x. If it was taken while active, its clock was at least a>=x. The sample contributes at least beta(x,1). Thresholds with b_l<=0 are conservatively credited zero.

It follows that the row excess is at most

    sum_t { beta(x_t,x_{t+1})
       -[S_h(x_{t+1};a)-S_h(x_t;a)] beta(x_t,1) } - A_h(a),

for an arbitrary decreasing path a=x_0>=...>=x_p=0.

## 5. Why the radius dynamic program covers arbitrary paths

Fix a path length and partition each radius coordinate at 0,a, every gamma_g, and every b_l(a) in [0,a]. Within a cell, the threshold coefficients are fixed and each subtracted reference bid is affine. Every positive transition bid is jointly convex. Therefore the excess is convex on the cell intersected with the row-order inequalities.

A maximum over the closure of that polytope occurs at a vertex. At a vertex, every block of equal radius coordinates touches an interval endpoint; otherwise the whole block could be perturbed both ways. Thus every vertex coordinate is a listed radius state.

At a threshold endpoint, the strict convention postpones charging until a later crossing and hence cannot decrease the excess, because the later pre-drop radius is no larger. This convention dominates the one-sided limits from adjacent cells. Repeated consecutive radii can be removed, since beta(x,x)=0. The resulting path is a decreasing path through the finite state set, and the displayed dynamic program considers every such path.

This argument holds for every original path length; no bound on the number of reconnections is assumed.

## 6. Scalar endpoints and the unbounded intervals

For each h, retain the distinct points in [rho,U_h] from this list:

* rho and U_h when finite;
* u_h/(u_h-1) when u_h>1;
* every gamma_g;
* every u_l and every u_l(1+gamma_g);
* 1+gamma_g/u_l and gamma_g*u_h/u_l, for l<h.

The explicit gamma_g points are important: in this new bid some reference breakpoints exceed rho. They were unnecessary in the earlier 1.883 certificate, whose largest reference breakpoint was below its target.

Between consecutive points, the radius-state order is fixed; each state is affine in a; its threshold mass is fixed; the negative reference terms and A_h(a) are affine. Each positive transition term is convex in a. The maximum path excess is therefore convex on the interval. The strict endpoint convention dominates its one-sided limits, so bounded intervals are controlled by their endpoints.

Only h=0,1 have unbounded intervals. Beyond their last finite endpoint, each symbolic path excess is a convex piecewise-affine function of a. Divide by a and let a tend to infinity. The normalized radii tend to values in {0,1,1/u_l}; the reference distance disappears; and the limiting excess is bounded by the zero-distance argument of Section 4. For h=1, the active mass at u_0=1 contributes asymptotic credit mu_0*a, exactly matching that zero-distance sample. Every recession slope is thus nonpositive.

A convex function on a ray with nonpositive asymptotic slope is nonincreasing: a positive secant slope would force a positive asymptotic slope. Hence the finite left endpoint controls the whole ray.

## 7. Exact arithmetic implementation

Write w_g=W_g/B and mu_l=M_l/D. Let G be a common denominator of the gamma values, and write gamma_g=p_g/G. With grid scale R, define

    N(X,Y)=sum_g W_g max(G*X-p_g*Y,0).

Then beta(X/R,Y/R)=N(X,Y)/(B*G*R). The verifier uses the common dynamic-program denominator B*G*R*D.

A positive transition is upper-bounded using ceil(R*x) for its source and floor(R*y) for its destination. A subtracted reference bid is lower-bounded using floor(R*x). Active reference arguments are rounded downward as well. Every threshold comparison and every scalar endpoint is computed as an exact rational number, not on the rounding grid.

Consequently, the integer dynamic program returns an upper bound on the exact rational dynamic program. This is directed rounding, not an error estimate for floating-point optimization. All masses, normalizations, CDF inequalities, finite endpoints, and target comparisons are checked exactly.

Rational construction uses signed 128-bit products of checked 64-bit components, with reduction and overflow checks. The dynamic program uses signed 128-bit integers only after a separate arbitrary-precision magnitude check. Arbitrary-precision integers are used for CDF checks and final comparisons. An input outside the implementation's arithmetic range is rejected rather than silently rounded or overflowed.

A successful run therefore proves q_j<=rho*d_j+C_j for every row. Summing, and using sum_j C_j<=f, proves the asserted all-dimensions upper bound.

## 8. Reproduction

Compile and run:

    g++ -O3 -std=c++17 verify.cpp -o verify
    ./verify certificate.txt
    python cross_check.py

The first run checks all endpoint cases. The Python script independently checks the CDF conditions, the exact single-outlier lower bound, and selected dynamic programs using fractions. Numerical optimization is used only to discover parameters, not by either verification command.

This is a computer-assisted mathematical proof, not a proof-assistant formalization. The finite arithmetic and the analytic reduction have separate roles; the latter is explicitly given above for independent review.


## Completed exact verification

The exact verifier checked 112,802 scalar endpoint cases and 120 cumulative-mass inequalities. Its largest outward-rounded upper bound was `184344982165038312381942179/100000000000000000000000000`, below the target `36869/20000`. The complete output is in `verification.txt`.
