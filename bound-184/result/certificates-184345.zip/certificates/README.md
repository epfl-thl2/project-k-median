# A 1.84345 upper bound for a bidding factor-revealing program

The principal document is `factor_revealing_184345.tex`; its compiled,
16-page version is `factor_revealing_184345.pdf`.

The theorem concerns the complete factor-revealing program restated in
Section 1. For the thirteen-component rational bid specified there, every
feasible solution, in every finite dimension, satisfies

    sum_j [sum_{i=j}^n beta(r_{j,i},r_{j,i+1}) + r_{j,n+1}]
        <= f + (36869/20000) sum_j d_j.

The analytic proof is self-contained. All bid coefficients, all 121
sampling masses, the endpoint construction, and both the mathematical and
integer dynamic programs are specified in the TeX. The finite arithmetic
is certified by the supplied verifier. No assertion about an underlying
algorithm or cardinality-constrained clustering problem is needed.

## Compile the note

With a LaTeX distribution containing the packages listed in the source:

    pdflatex factor_revealing_184345.tex
    pdflatex factor_revealing_184345.tex

The TeX uses no external bibliography, figure, or input files. Certificate
files are not needed to compile it.

## Reproduce the full certificate check

From this directory, with a C++17 compiler supporting __int128 and the
Boost.Multiprecision headers installed:

    g++ -O3 -std=c++17 verify.cpp -o verify
    ./verify certificate.txt

The archived verifier and certificate data are unchanged. The verifier
checks 120 cumulative-mass inequalities and 112,802 scalar endpoint cases.
The largest outward-rounded endpoint bound is

    184344982165038312381942179 / 10^26,

strictly below 36869/20000. This is a directed-rounding upper bound, not
an asserted exact maximum of the unrounded dynamic programs.

`verification.txt` records the successful rerun performed when preparing
this TeX note. The analytic reduction in the note—not an extrapolation
from the endpoint count—extends this finite check to every dimension and
every feasible radius trajectory.

## Supplementary independent checks

After compiling the C++ verifier, run from this directory:

    python cross_check.py
    python verify_lower_bound.py
    python audit_inputs.py

These scripts use Python's standard library. The first checks the CDF
conditions and selected unrounded rational dynamic programs against the
C++ upper bounds. It does not replace the all-endpoint C++ check. The
second checks the nearly matching lower-bound family in Appendix B.
The third checks that the two certificate formats and the TeX tables
agree exactly, and independently reconstructs the endpoint count.

The corresponding records are `independent_checks.txt`,
`lower_bound_checks.txt`, and `input_audit.txt`.

`certificate.json` is the machine-readable input to the supplementary
checks; it specifies the same mathematical data as `certificate.txt`.
`PROOF.md` is the original archived explanation of the certificate;
the TeX note supplies the expanded, self-contained exposition.
`SHA256SUMS` identifies all delivered files except the checksum file itself.

This is a computer-assisted mathematical proof. The verifier checks the
finite arithmetic; it is not a proof-assistant formalization of the
analytic lemmas.
