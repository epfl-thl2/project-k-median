"""Independent exact checks using Python's standard library.
This is supplementary to verify.cpp, which checks every scalar endpoint.
"""
import json, bisect, re, subprocess
from pathlib import Path
from fractions import Fraction as F

j=json.loads(Path('certificate.json').read_text())
g=list(map(F,j['gammas']));w=[F(x,j['bid_denominator']) for x in j['bid_integers']]
u=list(map(F,j['times']));mu=[F(x,j['mass_denominator']) for x in j['mass_integers']]
rho=F(j['target']);cw=[F(0)];cp=[F(0)]
for ga,we in zip(g,w):cw.append(cw[-1]+we);cp.append(cp[-1]+ga*we)
assert sum(w)==sum(mu)==1 and min(w)>=0 and min(mu)>=0 and min(g)>=1

def beta(x,y):
    x,y=F(x),F(y)
    k=len(g) if not y else bisect.bisect_left(g,x/y)
    return x*cw[k]-y*cp[k]

for l in range(1,len(u)):
    assert sum(mu[:l])>=beta(u[l],1)/(u[l]-1)

points={F(0),*g,*[1/(ga-1) for ga in g if ga>1]}
values=[(z+beta(z+1,z)-beta(z,1),str(z)) for z in points]
values.append((cp[-1],'infinity'))
value,z=max(values)
print('Exact single-outlier supremum:',value)
print('Attained at z =',z)
print('Decimal:',float(value))
assert z != 'infinity' or value==cp[-1]


def dp(h,a):
    bs=[a/t-1 for t in u]
    r=sorted({F(0),a,*[x for x in g+bs if 0<=x<=a]})
    s=[sum((mu[l] for l in range(h,len(u)) if bs[l]>x),F(0)) for x in r]
    ref=[beta(x,1) for x in r];v=[F(0)]*len(r)
    for k in range(1,len(r)):
        v[k]=max(beta(r[k],r[p])-(s[p]-s[k])*ref[k]+v[p] for p in range(k))
    m=max(a-1,a/u[h]);active=sum((mu[l]*beta(m*u[l],1) for l in range(h)),F(0))
    return v[-1]-active

record=Path('verification.txt').read_text()
assert record.startswith('PASS'), 'The all-endpoint C++ check has not passed.'
m=re.search(r'Worst checked case: h=(\d+), a=([^\s]+)',record)
assert m
cases=[(int(m.group(1)),F(m.group(2))),(0,rho),(1,F(97)),(1,F(47,18)),(10,F(2)),(30,F(5,2)),(60,F(47,18)),(100,rho)]
for h,a in sorted(set(cases)):
    if h>=2 and a>u[h-1]/(u[h-1]-1):continue
    exact=dp(h,a)
    out=subprocess.check_output(['./verify','certificate.txt',str(h),str(a.numerator),str(a.denominator)],text=True)
    rounded=F(out.splitlines()[0]);assert exact<=rounded<=rho
    print('PASS independent Fraction DP:',h,str(a),'exact',str(exact),'rounded',str(rounded))
print('All independent checks passed.')
